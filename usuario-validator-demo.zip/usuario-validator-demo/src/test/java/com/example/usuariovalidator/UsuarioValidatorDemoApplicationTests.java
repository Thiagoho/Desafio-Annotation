package com.example.usuariovalidator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuarioValidatorDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
